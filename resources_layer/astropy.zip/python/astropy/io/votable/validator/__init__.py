# Licensed under a 3-clause BSD style license - see LICENSE.rst
from .main import make_validation_report

from . import main
__doc__ = main.__doc__
del main
