# Licensed under a 3-clause BSD style license - see LICENSE.rst

# This sub-package makes use of image testing with the pytest-mpl package:
#
# https://pypi.org/project/pytest-mpl
#
# For more information on writing image tests, see the 'Image tests with
# pytest-mpl' section of the developer docs.
